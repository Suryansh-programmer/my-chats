class AlertSystem {
    constructor() {
        this.alertVisible = false; // Track visibility to prevent overlap
        this.alertElement = document.getElementById('alert'); // Use a single alert element
    }

    showAlert(message, type = 'info', duration = 5000) {
        if (this.alertVisible) return; // Prevent showing multiple alerts at the same time

        this.alertVisible = true;
        this.alertElement.className = `alert ${type}`; // Update alert type
        this.alertElement.innerHTML = `<p>${message}</p>`;

        // Show the alert with animations
        setTimeout(() => {
            this.alertElement.classList.add('show');
        }, 10);

        // Hide the alert after a specific duration
        setTimeout(() => {
            this.hideAlert();
        }, duration);
    }

    hideAlert() {
        this.alertElement.classList.remove('show');

        setTimeout(() => {
            this.alertVisible = false; // Allow new alerts
        }, 500); // Wait for transition to complete
    }
}

// Initialize the alert system once for the website
const alertSystem = new AlertSystem();
function alert(message){
    alertSystem.showAlert(message, 'success');
}

