const taskSection = document.querySelector("#tasks-section");
const completedTaskSection = document.querySelector("#completed-tasks-section");
let tokenElement = document.querySelector("#scrollToken");

let botToken;
let user_id;
let token;
let username;
const botCrawling = document.querySelector(".bot");



let duration = 2500;
let end = Date.now() + duration;
let colors = ["#ff0", "#0f0", "#00f", "#f00", "#f0f", "#0ff"];
let centerX = window.innerWidth / 2;
let centerY = window.innerHeight / 2;

let daysStreak = document.querySelectorAll(".days-streak");

// !Function to launch confetti
function launchConfetti() {
  function randomEdge() {
    const side = Math.floor(Math.random() * 4);
    switch (side) {
      case 0:
        return { x: Math.random(), y: 0 }; // Top
      case 1:
        return { x: 1, y: Math.random() }; // Right
      case 2:
        return { x: Math.random(), y: 1 }; // Bottom
      case 3:
        return { x: 0, y: Math.random() }; // Left
    }
  }

  (function frame() {
    const { x: edgeX, y: edgeY } = randomEdge();
    confetti({
      particleCount: 10,
      angle:
        Math.atan2(
          centerY - edgeY * window.innerHeight,
          centerX - edgeX * window.innerWidth
        ) *
        (180 / Math.PI),
      spread: 70,
      origin: { x: edgeX, y: edgeY },
      colors: colors,
      shapes: ["circle", "square", "star"],
      startVelocity: 30,
    });
    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  })();
}





// !Function to set item in telegram cloud storage
function setItem(key, value) {
  if (window.Telegram.WebApp && window.Telegram.WebApp.setStorage) {
      try {
          window.Telegram.WebApp.setStorage({ [key]: value });
          console.log(`Item set: ${key} = ${value}`);
      } catch (error) {
          console.error("Failed to set item in storage:", error);
      }
  } else {
      localStorage.setItem(key,value);
  }
}




// !Function to get item from cloud storage 
function getItem(key) {
  if (window.Telegram.WebApp && window.Telegram.WebApp.getStorage) {
      try {
          window.Telegram.WebApp.getStorage([key], (storage) => {
              let value = storage[key];
              if (value !== undefined) {
                  console.log(`Item retrieved: ${key} = ${value}`);
                  return value;
              } else {
                  console.log(`Item not found for key: ${key}`);
                  return null;
              }
          });
      } catch (error) {
          value = localStorage.getItem(key);
          return value;
      }
  } else {
    value = localStorage.getItem(key);
    return value;
      
  }
}






// !Function to handle error 
function handleError(){
  let main = document.querySelector("main");
  let loader = document.querySelector(".loader");
  let home  = document.querySelector(".home");
  let tasks = document.querySelector(".tasks");
  let leaderboard = document.querySelector(".leaderboard");
  let friends = document.querySelector(".friends");
  let airdrop = document.querySelector(".airdrop");
  let staking = document.querySelector(".staking");

  let mainRank = document.querySelector(".main-rank");
  let navbar = document.querySelector(".navbar");

  let allElements = [loader,home,tasks,leaderboard,friends,airdrop,staking,mainRank,navbar,main];

  allElements.forEach(element =>{
    // element.remove();
    element.style.display = "none";
  })

  let webUser = document.querySelector(".web-user");
  webUser.style.display = "block";

}







// !Function for fetching/updating data from back-end
async function fetchData(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Request failed with status: ${response.status}`);
    }
    return await response.json(); // Parse and return JSON
  } catch (error) {
    console.error("Error:", error);
    alert("Something went wrong! Please contact the support team.");
    throw error; // Propagate the error
  }
}

// !Function to check for refer
function checkRefer() {
  // Get the full URL
  let url = new URL(window.location.href);

  // Use URLSearchParams to extract the value of 'startapp'
  let params = new URLSearchParams(url.search);
  let startappValue = params.get("startapp");
  if(check(startappValue)){

  }else{
    startappValue = params.get("tgWebAppStartParam");
  }
  let dataToSend = window.Telegram.WebApp.initData;

  // Log the value to the console
  if (check(startappValue)) {
    const urlSend = `/?startapp=${encodeURIComponent(startappValue)}&data=${encodeURIComponent(dataToSend)}`;

    fetchData(urlSend) // Use the fetch helper
      .then((data) => {
      })
      .catch((error) => {
        console.error("Error in sendData:", error);
      });

    return "Success";
  } else {
    return "Error";
  }
}

// !Getting data from back-end
if (window.Telegram.WebApp.initData) {
  window.Telegram.WebApp.expand();
  // Construct the URL dynamically
  let url = `/getData/${window.Telegram.WebApp.initData}/`;

  checkRefer(); // Call the refer function

  fetch(url)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      handleData(data); // Call your data handler function
    })
    .catch((error) => {
      handleError();
      console.error("Error:", error);
      alert("An error occurred! Contact support team!");
    });
} else {
  handleError();
}

function extractUsernameFromLink(link) {
  // Regular expression to match the username in the link
  const regex = /https:\/\/t\.me\/(@?[a-zA-Z0-9_]+)/;
  const match = link.match(regex);

  if (match && match[1]) {
    // Remove the '@' if present
    return match[1].replace(/^@/, "");
  } else {
    console.error("Username not found in the link.");
    return null;
  }
}

//! Function to get channel Id
async function getChannelId(channelLink) {
  try {
    // Extract the username from the channel link
    let username = extractUsernameFromLink(channelLink);

    // Build the API request URL
    const url = `https://api.telegram.org/bot${botToken}/getChat?chat_id=@${username}`;

    // Make the API request and wait for the response
    const response = await fetch(url);

    // Parse the response as JSON
    const data = await response.json();

    // Check if the response is successful
    if (data.ok) {
      return data.result.id;
    } else {
      console.error("Error fetching channel info:", data.description);
      return null;
    }
  } catch (error) {
    console.error("Error:", error);
    return null;
  }
}

//! Function to check if a user is a member of a specific Telegram channel
async function isUserMemberOfChannel(userId, urllink) {
  let channelId = await getChannelId(urllink);
  const url = `https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${channelId}&user_id=${userId}`;
  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.ok) {
      const status = data.result.status;
      // The user is a member if the status is "member", "administrator", or "creator"
      if (
        status === "member" ||
        status === "administrator" ||
        status === "creator"
      ) {
        return true;
      }
      return false;
    } else {
      console.error("Error checking membership:", data.description);
      return false;
    }
  } catch (error) {
    console.error("Error fetching chat member data:", error);
    return false;
  }
}

//! Function to get random number
function getRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// !Function to update the token on server side
async function updateToken(user, token, query) {
  try {
    let url = `/updateToken/${user},${token},${query}`;

  let data = await fetchData(url); // Use the fetch helper
  let tokenClass = document.querySelectorAll(".token");

  tokenClass.forEach((element) => {
    if (!element.innerText || isNaN(element.innerText)) {
      element.innerText = 0;
    }
    element.setAttribute("data-val", data.token);
  });

  let levelClass = document.querySelectorAll(".levels");
  levelClass.forEach((element) => {
    let level = getLevel(data.token);
    element.innerText = level;
  });
  
  } catch (error) {
    updateToken(user,token,query);
    
  }
  
}

// !Function to scroll to token
function scrollToToken() {
  tokenElement.scrollIntoView({
    behavior: "smooth", // Can be 'auto' (default) or 'smooth'
    block: "start", // Aligns the element at the top of the view
    inline: "nearest", // Aligns the element to the nearest edge
  });
}

// !Function to get welcome gift  value
function getGiftValue() {
  // Initialize the list
  let nums = [];
  // Generate 8 random numbers between 1000 and 2000
  for (let i = 0; i < 8; i++) {
    nums.push(getRandomNumber(1000, 2000));
  }

  // Generate 2 random numbers between 2000 and 5000
  for (let i = 0; i < 2; i++) {
    nums.push(getRandomNumber(2000, 5000));
  }
  let num = Math.round(Math.random() * 10);
  num = num - 1;
  let rewardDaily = nums[num];
  if (rewardDaily == undefined) {
    rewardDaily = getRandomNumber(1000, 2000);
    if (rewardDaily == undefined) {
      rewardDaily = getRandomNumber(1000, 2000);
      if (rewardDaily == undefined) {
        rewardDaily = 1178 || 2579;
      }
    }
  }

  return rewardDaily;
}

// !Function to update task on server side
async function updateTask(id, user) {
  const url = `/updateTask/${id},${user}`;

  const data = await fetchData(url); // Use the fetch helper
  return data; // Return the response data
}

// !Function to update daily reward on server side
function updateReward(user, num, day) {
  const url = `/updateReward/${user},${num},${day}`;

  fetchData(url) // Use the fetch helper
    .then((data) => {
      daysStreak.forEach((element) => {
        element.innerText = data.rewards.length;
      });
    })
    .catch((error) => {
      console.error("Error in updateReward:", error);
    });
}

// !Function to get level form token
const getLevel = (token) => {
  let level; // Declare level outside the if blocks

  if (token <= 1000) {
    level = 1;
  } else {
    let updatedToken = token - 1000;
    level = Math.ceil(updatedToken / 500) + 1;
  }

  if (level > 50) {
    level = 50;
  }

  return level;
};

function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + "k";
  } else {
    return num;
  }
}

// !Function to check value is not none
function check(value) {
  if (value !== undefined && value !== null && isNaN(value)) {
    return true;
  } else {
    return false;
  }
}

// !Function to load leaderboard on website
function loadLeaderboard(response) {
  let leaderboard = response.leaderboard;
  let leaderboardContainer = document.querySelector(".leaderboard-container");
  let topContainer = document.createElement("div");
  let mainRank = document.querySelector("#userRank");
  let mainUsername = document.querySelector(".user-name");
  let mainToken = document.querySelector(".tokenRank");

  let otherUser = document.createElement("div");
  otherUser.classList.add("other-users");
  topContainer.classList.add("top-3-container");
  if (check(leaderboard?.[0])) {
    let firstUser = document.createElement("div");
    firstUser.classList.add("top-user");
    firstUser.classList.add("first");
    firstUser.innerHTML = `<div class="crown">&#x1F451;</div><div class="user-info">
                            <h2>${leaderboard[0].username}</h2>
                            <p>Points: ${formatNumber(
      leaderboard[0].token
    )}</p></div>`;
    topContainer.append(firstUser);
    if (check(leaderboard?.[1])) {
      let secondUser = document.createElement("div");
      secondUser.classList.add("top-user");
      secondUser.classList.add("second");
      secondUser.innerHTML = `<div class="crown">&#x1F948;</div><div class="user-info">
                                <h2>${leaderboard[1].username}</h2>
                                <p>Points: ${formatNumber(
        leaderboard[1].token
      )}</p></div>`;
      topContainer.append(secondUser);
    }
    if (check(leaderboard?.[2])) {
      let thirdUser = document.createElement("div");
      thirdUser.classList.add("top-user");
      thirdUser.classList.add("second");
      thirdUser.innerHTML = `<div class="crown">&#x1F949;</div><div class="user-info">
                                    <h2>${leaderboard[2].username}</h2>
                                    <p>Points: ${formatNumber(
        leaderboard[2].token
      )}</p></div>`;
      topContainer.append(thirdUser);
      for (i = 3; i < 49; i++) {
        let userLeaderboard = leaderboard?.[i];
        let userLeaderboardElement = document.createElement("div");
        if (check(userLeaderboard)) {
          userLeaderboardElement.innerHTML = `<div class="user-row"><div class="rank">#${i + 1
            }</div><div class="user-info"><h3>${userLeaderboard.username
            }</h3><p>Points: ${formatNumber(
              userLeaderboard.token
            )}</p></div></div>`;
          otherUser.append(userLeaderboardElement);
        } else {
          break;
        }
      }
    }
  }
  mainRank.innerHTML = `#${response.rank}`;
  mainUsername.innerHTML = response.username;
  mainToken.innerHTML = formatNumber(response.token);
  leaderboardContainer.append(topContainer);
  leaderboardContainer.append(otherUser);
}

// !Function to load friends on webpage
function loadFriends(response) {
  let inviteLink = document.querySelector("#invite-link");
  inviteLink.setAttribute("value", response.invite_link);

  let friendsList = document.querySelector(".friends-list");
  if (response.friends > 0) {
    response.invited.forEach((element) => {
      friendCard = document.createElement("div");
      friendCard.classList.add("friend-item");
      friendCard.innerHTML = `<div class="friend-info"><h3>${element.username}</h3><p>Joined: ${element.time}</p></div><button class="friend-status">+58 Points </button>`;
      friendsList.append(friendCard);
    });
  } else {
    let noFriendsMessage = document.querySelector(".no-friends-message");
    noFriendsMessage.style.display = "block";
    friendsList.style.display = "none";
  }
}

// ?Function for updating battery
function updateBattery(limit) {
  const batteryFill = document.querySelector(".battery-fill");
  const batteryLevel = document.querySelector(".battery-level");
  let totalLimit = getItem(`total-limit`);
  let part = (limit * 100) / totalLimit;
  batteryFill.style.width = part + "%";
  batteryLevel.textContent = limit;
}

//! Function to get limit for tap tap game
function getLimit() {
  let level = getLevel(token);
  if (level == 1) {
    limit = 1000;
  } else {
    level = level - 1;
    limit = level * 500 + 1000;
  }
  setItem(`limit`, limit);
  setItem(`total-limit`, limit);
}



// !Function to update token values in "".token" element 
async function updateTokenValues(token) {
  return new Promise((resolve) => {
    let tokenClass = document.querySelectorAll(".token");

    tokenClass.forEach(element => {
      element.innerHTML = token;
    });

    resolve();  // Resolve the promise after all updates are complete
  });
}






// !Function for handling main data
async function handleData(response) {
  token = response.token;
  botToken = response.botToken;
  token = Number.isNaN(token) ? 0 : token;
  user_id = response.user_id;
  
  await updateTokenValues(response.token);
  loadTask(response);
  loadFriends(response);
  loadLeaderboard(response);
  await updatePlayToken(user_id);
  
  let tokenRemaining = getItem(`token`);
  let level = getLevel(token);



  let checkLimit = getItem(`limit`);
  let checkTotalLimit = getItem(`total-limit`);

  if (
    tokenRemaining == null ||
    tokenRemaining === undefined ||
    isNaN(tokenRemaining)
  ) {
    // If the token doesn't exist, set it to 0
    tokenRemaining = 0;
    setItem(`token`, 0);
  } else {
    if (tokenRemaining > 0) {
      await updateToken(user_id, tokenRemaining, "null");
    }
  }

  if (checkLimit == null || checkLimit === undefined || isNaN(checkLimit)) {
    limit = getLimit();
  }
  if (
    checkTotalLimit == null ||
    checkTotalLimit === undefined ||
    isNaN(checkTotalLimit)
  ) {
    limit = getLimit();
  }

  // Hide the loading animation
  let loading = document.querySelector(".loader");
  loading.style.display = "none";

  let navbar = document.querySelector(".navbar");
  navbar.style.display = "flex";

  // Show the main content
  // Displaying home
  let content = document.querySelector(".home");
  content.style.display = "block";

  // ?Entering value for daily streak
  daysStreak.forEach((element) => {
    if (check(response.rewards)) {
      element.innerText = response.rewards.length;
    } else {
      element.innerText = 0;
    }
  });

  // ?Entering value for username classes
  let usernameClass = document.querySelectorAll(".username");
  usernameClass.forEach((element) => {
    element.innerText = response.username;
  });

  // ?Entering value for level classes
  let levelClass = document.querySelectorAll(".levels");
  levelClass.forEach((element) => {
    element.innerText = level;
  });

  // ?Entering value for playPass classes
  let ticketClass = document.querySelectorAll(".pass");
  let passAvailable = response.playPass;
  ticketClass.forEach((element) => {
    element.innerText = passAvailable;
  });

  // ?Updating token value

  // ?Handling Dragon for T-rexg game
  document.getElementById("dragon").onclick = function () {
    if (passAvailable > 0) {
      // Start the dragon's animation
      this.classList.add("dragon-run");
      // Wait for the animation to complete before starting the game
      setTimeout(function () {
        // Start the T-Rex runner game
        document.getElementById("dragon").classList.remove("dragon-run");
        var data = { user_id: user_id, playPass: parseInt(passAvailable) };

        // Convert data to a query string
        var queryString = Object.keys(data)
          .map(
            (key) =>
              encodeURIComponent(key) + "=" + encodeURIComponent(data[key])
          )
          .join("&");

        // Redirect to the new URL with the data
        window.location.href = "/game?" + queryString;
      }, 2000); // Match this time to your animation duration
    } else {
      alert("You don't have enough play pass to play the game ");
    }
  };

  if (response.user) {
    if (response.daily_reward == true) {
      let content = document.querySelector(".main-home");
      content.style.display = "block";
    } else {
      launchConfetti();
      let daily = document.querySelector("#daily");
      daily.style.display = "block";
      let reward = document.querySelector("#daily-reward");
      let day = new Date().getDate();
      let tokenUpdated;
      if (response.rewards.length == 0) {
        let num = 200;
        reward.innerText = num;
        updateToken(user_id, num, "null");
        updateReward(user_id, num, day);
      } else {
        let rewards = response.rewards;
        let previousDay = rewards.at(-1).day;
        let num;
        if ((day - previousDay) <= 1) {
          num = rewards.at(-1).reward;
          num = num * 2;
        } else {
          num = 200;
        }
        reward.innerText = num;
        let tokenClass = document.querySelectorAll(".token");

        tokenClass.forEach((element) => {
          if (!element.innerText || isNaN(element.innerText)) {
            element.innerText = 0;
          }
          element.setAttribute("data-val", (parseInt(element.innerText) + parseInt(num)));
        });
        let returntoken = await updateToken(user_id, num, "null");
        tokenUpdated = returntoken.token;
        updateReward(user_id, num, day);
      }

      let limit;
      limit = getLimit();
    }
  } else {
    launchConfetti();
    gift = document.querySelector("#gift");
    gift.style.display = "block";
    let reward = document.querySelector("#gift-reward");
    let rewardDaily = getGiftValue();
    reward.innerText = rewardDaily;
    let tokenClass = document.querySelectorAll(".token");

    tokenClass.forEach((element) => {
      if (!element.innerText || isNaN(element.innerText)) {
        element.innerText = 0;
      }
      element.setAttribute("data-val", (parseInt(element.innerText) + parseInt(rewardDaily)));
    });
    await updateToken(user_id, rewardDaily, "gift");
    limit = getLimit();
  }
}

let closeButtonDaily = document.querySelector("#close-icon-daily");
let claimButtonDaiy = document.querySelector("#claim-daily-reward");
let closeButtonWelcome = document.querySelector("#close-icon-welcome");
let claimButtonWelcome = document.querySelector("#claim-button-welcome");
let elements = [
  closeButtonDaily,
  claimButtonDaiy,
  closeButtonWelcome,
  claimButtonWelcome,
];
elements.forEach((element) => {
  element.addEventListener("click", () => {
    // Select all elements with the class 'gift'
    let giftClass = document.querySelectorAll(".gift");

    // Loop through each element and set its display style to 'none'
    giftClass.forEach((el) => (el.style.display = "none"));

    let content = document.querySelector(".main-home");
    content.style.display = "block";

    let tokenDisplays = document.querySelectorAll(".token");

    tokenDisplays.forEach((tokenDisplay) => {
      let startValue = parseInt(tokenDisplay.innerText);
      let endValue = parseInt(tokenDisplay.getAttribute("data-val"));
      let duration = 1000; // Duration in milliseconds
      let startTime = performance.now();

      function updateCounter(currentTime) {
        let elapsedTime = currentTime - startTime;
        let progress = Math.min(elapsedTime / duration, 1);
        let currentValue = Math.round(
          startValue + (endValue - startValue) * progress
        );

        tokenDisplay.innerHTML = currentValue;

        if (progress < 1) {
          requestAnimationFrame(updateCounter);
        }
      }

      requestAnimationFrame(updateCounter);
    });
  });
});

let closeButtonTap = document.querySelector("#close-icon-tap");
let claimButtonTap = document.querySelector("#claim-button-tap");
let elementTap = [closeButtonTap, claimButtonTap];
elementTap.forEach((element) => {
  element.addEventListener("click", async () => {
    try {
      // Hide all elements with the class 'gift'
      document
        .querySelectorAll(".gift")
        .forEach((el) => (el.style.display = "none"));

      // Display the main home content
      const content = document.querySelector(".main-home");
      content.style.display = "block";

      // Get token value from localStorage
      let tokenTap = getItem(`token`) || 0; // Fallback to 0 if token is not found

      // Update token on the server
      updateToken(user_id, tokenTap, "tap-tap");
      // Reset local storage token to 0
      setItem(`token`, 0);

      // Update the displayed token values with an animation
      document.querySelectorAll(".token").forEach((tokenDisplay) => {
        numberAnimation(tokenDisplay, tokenTap);
      });
      tapEarnings.innerText = 0;
    } catch (error) {
      console.error("Error during operation:", error);
    }
  });
});

let tapImg = document.querySelector("#tap-img");
let tapEarnings = document.querySelector("#tap-earnings");

tapImg.addEventListener("click", () => {
  let limitTap = getItem(`limit`);
  let limitBattery = limitTap - 1;
  let batteryContainer = document.querySelector(".battery-container");
  updateBattery(limitBattery);
  if (limitBattery <= 0) {
    alert("Limit exceded , Try again tomorrow ");
  } else {
    // Create a new floating number element
    let floatingNumber = document.createElement("div");
    floatingNumber.className = "floating-number";
    floatingNumber.textContent = "+1";

    // Add the floating number to the body or a specific container
    batteryContainer.appendChild(floatingNumber);

    // Set initial position and animate
    floatingNumber.style.position = "absolute";
    floatingNumber.offsetHeight;
    floatingNumber.style.animation = "floatUp 2s forwards";

    // Remove the element after the animation is complete
    floatingNumber.addEventListener("animationend", function () {
      floatingNumber.remove();
    });

    // Add the glow effect to the image
    tapImg.classList.add("glow");

    // Remove the glow effect after the animation ends
    setTimeout(function () {
      tapImg.classList.remove("glow");
    }, 600); // Match this duration with the glow animation duration

    let tokenTap = getItem(`token`);
    if (tokenTap == null || tokenTap === undefined || isNaN(tokenTap)) {
      // If the token doesn't exist, set it to 0
      tokenTap = 0;
      setItem(`token`, 0);
    }
    if (limitTap == null || limitTap === undefined || isNaN(limitTap)) {
      // If the token doesn't exist, set it to 0
      getLimit();
    }

    tapEarnings.innerText = parseInt(tapEarnings.innerText) + parseInt(1);
    tokenTap = parseInt(tokenTap) + parseInt(1);
    setItem(`token`, tokenTap);
    setItem(`limit`, limitTap - 1);
  }
});

// Defining variables for all sections
let sections = {
  home: document.querySelector(".home"),
  tasks: document.querySelector(".tasks"),
  leaderboard: document.querySelector(".leaderboard"),
  friends: document.querySelector(".friends"),
  airdrop: document.querySelector(".airdrop"),
  staking: document.querySelector(".staking"),
};

// Defined variables for navbar click
let navClicks = {
  home: document.querySelector("#home"),
  tasks: document.querySelector("#tasks"),
  leaderboard: document.querySelector("#leaderboard"),
  friends: document.querySelector("#friends"),
  airdrop: document.querySelector("#airdrop"),
  tasksHome: document.querySelector("#tasks-home"),
  staking: document.querySelector("#staking"),
};
let mainRank = document.querySelector(".main-rank");
// Function to handle section switching
function switchSection(activeSection) {
  // Hide all sections
  if (activeSection == "leaderboard") {
    mainRank.style.display = "block";
  } else {
    mainRank.style.display = "none";
  }
  for (let section in sections) {
    sections[section].style.display = "none";
  }

  // Remove 'active' class from all navbar items
  for (let nav in navClicks) {
    navClicks[nav].classList.remove("active");
  }

  // Show the active section
  sections[activeSection].style.display = "block";
  navClicks[activeSection].classList.add("active");
}

// Making Navbar working
navClicks.home.addEventListener("click", () => switchSection("home"));
navClicks.tasks.addEventListener("click", () => switchSection("tasks"));
navClicks.leaderboard.addEventListener("click", () =>
  switchSection("leaderboard")
);
navClicks.friends.addEventListener("click", () => switchSection("friends"));
navClicks.airdrop.addEventListener("click", () => switchSection("airdrop"));
navClicks.tasksHome.addEventListener("click", () => switchSection("tasks"));
navClicks.staking.addEventListener("click", () => switchSection("staking"));

let taptapClick = document.querySelector("#tap-tapClick");
let taptap = document.querySelector("#tap-tap");
taptapClick.addEventListener("click", (element) => {
  taptap.style.display = "block";
  let mainHome = document.querySelector(".main-home");
  mainHome.style.display = "none";
  let limitBattery = getItem(`limit`);
  updateBattery(limitBattery);
  tapEarnings.innerText = 0;
});

// Script to handle invite popup
function openInvitePopup() {
  document.getElementById("invite-popup").style.display = "flex";
}

function closeInvitePopup() {
  document.getElementById("invite-popup").style.display = "none";
}

// Script to copy invite link to clipboard
function copyInviteLink() {
  var copyText = document.getElementById("invite-link");
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */
  navigator.clipboard
    .writeText(copyText.value)
    .then(() => alert("Invite link copied"))
    .catch(() => alert("Copy failed"));

  alert("Invite link copied: " + copyText.value);
}

// Script to share invite link (Example using Web Share API)
function shareInviteLink() {
  if (navigator.share) {
    navigator
      .share({
        title: "Invite to Our Platform",
        text: "Join me on this awesome platform!",
        url: document.getElementById("invite-link").value,
      })
      .then(() => {
      })
      .catch((error) => {
        console.error("Something went wrong sharing the link", error);
      });
  } else {
    alert(
      "Web Share API is not supported in your browser. Please copy the link manually."
    );
  }
}

function addCompletedTask(title, reward, method) {
  let completedTaskElement = document.createElement("div");
  completedTaskElement.classList.add("completed-task-card");
  completedTaskElement.innerHTML = `<h3 class="completed-task-title">${title} </h3><p class="completed-task-reward">Reward: ${reward} Points</p>`;

  if (method == "append") {
    completedTaskSection.append(completedTaskElement);
  } else if (method == "prepend") {
    completedTaskSection.prepend(completedTaskElement);
  }
}

function createTaskCard(title, reward) {
  let taskCard = document.createElement("div");
  taskCard.classList.add("task-card");
  let taskInfo = document.createElement("div");
  taskInfo.classList.add("task-info");
  taskInfo.innerHTML = `<h3 class="task-title">${title}</h3>
                <p class="task-reward">Reward: ${reward} Points</p>`;
  taskCard.append(taskInfo);
  return taskCard;
}

function numberAnimation(element, taskReward) {

  let startValue = parseInt(element.innerText);
  let endValue = parseInt(startValue) + parseInt(taskReward);

  let duration = 1000; // Duration in millisecondsta
  let startTime = performance.now();
  function updateCounter(currentTime) {
    let elapsedTime = currentTime - startTime;
    let progress = Math.min(elapsedTime / duration, 1);
    let currentValue = Math.round(
      startValue + (endValue - startValue) * progress
    );

    element.innerText = currentValue;

    if (progress < 1) {
      requestAnimationFrame(updateCounter);
    }
  }
  requestAnimationFrame(updateCounter);
}

function createTaskButton(logic, taskId) {
  let taskButton = document.createElement("button");
  taskButton.classList.add("claim-button");
  taskButton.id = taskId;
  taskButton.innerHTML = `<span>${logic}</span>`;
  return taskButton;
}

function loadTask(response) {
  tasks = response.tasks_list;
  taskId = 0;
  tasks.forEach((element) => {
    taskId++;
    taskCompletion = element.completed;
    checkCompletion = taskCompletion[response.user_id];
    if (checkCompletion == false) {
      let taskCard = createTaskCard(element.title, element.reward);
      let taskButton = createTaskButton(element.logic, taskId);

      taskCard.append(taskButton);
      taskSection.append(taskCard);
      if (element.mode == "Normal") {
        if (check(element.url)) {
          taskButton.addEventListener("click", () => {
            window.open(element.url, "_blank"); // Opens the link in a new tab
            taskButton.parentNode.removeChild(taskButton);
            let checkButton = createTaskButton("Check", taskId);
            taskCard.append(checkButton);
            checkButton.addEventListener("click", async () => {
              checkButton.classList.add("loading");
              let taskReward = element.reward;
              setTimeout(() => {
                taskButton.classList.remove("loading");
                updateToken(user_id, taskReward, "null");
                updateTask(element.id, user_id);
                // Assuming newElement is already appended to the DOM
                taskSection.removeChild(taskCard);
                addCompletedTask(element.title, element.reward, "prepend");
                scrollToToken();
                document.querySelectorAll(".token").forEach((element) => {
                  numberAnimation(element, taskReward);
                });
              }, 3000);
            });
          });
        } else {
          taskButton.addEventListener("click", () => {
            taskButton.classList.add("loading");
            let taskReward = element.reward;
            updateToken(user_id, taskReward, "null");
            updateTask(element.id, user_id);
            setTimeout(() => {
              taskButton.classList.remove("loading");
              // Assuming newElement is already appended to the DOM
              taskCard.parentNode.removeChild(taskCard);

              addCompletedTask(element.title, element.reward, "prepend");
              scrollToToken();
              document.querySelectorAll(".token").forEach((element) => {
                numberAnimation(element, taskReward);
              });
            }, 3000);
          });
        }
      } else if (element.mode == "Url") {
        taskButton.addEventListener("click", () => {
          window.open(element.url, "_blank"); // Opens the link in a new tab
          taskButton.parentNode.removeChild(taskButton);
          let checkButton = createTaskButton("Check", taskId);
          taskCard.append(checkButton);
          checkButton.addEventListener("click", async () => {
            checkButton.classList.add("loading");
            let taskReward = element.reward;
            let checkUser = false;
            await isUserMemberOfChannel(response.user_id, element.url)
              .then((result) => {
                checkUser = result; 
              })
              .catch((error) => {
                console.error("Error:", error); // Logs any errors that occur
              });
            setTimeout(() => {
              checkButton.classList.remove("loading");
              if (checkUser == true) {
                updateToken(user_id, taskReward, "null");
                updateTask(element.id, user_id);
                // Assuming newElement is already appended to the DOM
                taskSection.removeChild(taskCard);

                addCompletedTask(element.title, element.reward, "prepend");
                scrollToToken();
                document.querySelectorAll(".token").forEach((element) => {
                  numberAnimation(element, taskReward);
                });
              } else {
                alert("Pls try again after joining the channel ");
              }
            }, 3000);
          });
        });
      } else if (element.mode == "Refer") {
        taskButton.addEventListener("click", () => {
          taskButton.classList.add("loading");
          let taskReward = element.reward;
          let checkUser = false;
          if (response.friends >= 5) {
            checkUser = true;
          }
          setTimeout(() => {
            taskButton.classList.remove("loading");
            if (checkUser == true) {
              updateToken(user_id, taskReward, "null");
              updateTask(element.id, user_id);
              // Assuming newElement is already appended to the DOM
              taskCard.parentNode.removeChild(taskCard);

              addCompletedTask(element.title, element.reward, "prepend");
              scrollToToken();
              document.querySelectorAll(".token").forEach((element) => {
                numberAnimation(element, taskReward);
              });
            } else {
              alert("Pls invite 5 friends first !");
            }
          }, 3000);
        });
      }
    } else {
      addCompletedTask(element.title, element.reward, "append");
    }
  });
  addCompletedTask("T-rex game ", response.game, "append");
  addCompletedTask("Tap Tap Game ", response.tapTap, "append");
  addCompletedTask(
    "Invite Friends",
    parseInt(response.friends) * parseInt(response.ReferPoints),
    "append"
  );
  addCompletedTask("Welcome Gift ", response.gift, "append");
}

async function updatePlayToken(user_id) {
  try {
    // Get token value from localStorage
    let tokenTap = parseInt(getItem(`currentScore`) || 0); // Fallback to 0 if token is not found
    // Update token on the server
    if (tokenTap > 0) {
      await updateToken(user_id, tokenTap, "game");
    }

    // Reset local storage token to 0
    setItem(`currentScore`, 0);
    // Update the displayed token values with an animation
    document.querySelectorAll(".token").forEach((tokenDisplay) => {
      numberAnimation(tokenDisplay, tokenTap);
    });
  } catch (error) {
    console.error("Error during operation:", error);
  }
}
