
from . import views
from django.urls import path 
urlpatterns = [
    path('',views.index,name='index'),
    path('getData/<str:data>/',views.getData,name='getData'),
    path('login/',views.CustomLoginForm.as_view(),name='login'),
    path('task-create/',views.taskCreate.as_view(),name='task-create'),
    path('updateToken/<str:user>,<int:token>,<str:query>',views.updateToken,name='updateToken'),
    path('updatePass/<str:user>',views.updatePass,name='updatePass'),
    path('updateReward/<str:user>,<int:num>,<int:day>',views.updateReward,name="updateReward"),
    path('updateTask/<int:id>,<str:user>',views.updateTask,name="updateTask"),
    path("game/",views.game,name='game')
]

