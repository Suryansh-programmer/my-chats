from django.core.management.base import BaseCommand
from mainapp.models import UserProfile  # Importing the UserProfile model
class Command(BaseCommand):
    help = 'Run my custom task'

    def handle(self, *args, **kwargs):
        # Add your task logic here
        print("Task executed at 12:00 AM UTC")
         # Update all UserProfile instances' daily_reward field to False
        updated_count = UserProfile.objects.update(daily_reward=False)
        self.stdout.write(self.style.SUCCESS(f'Successfully reset daily_reward for {updated_count} users'))