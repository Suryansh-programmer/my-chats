from django.shortcuts import render,redirect
from django.http import HttpResponse,JsonResponse
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView,UpdateView,DeleteView,FormView
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
import urllib.parse
import json
from.models import tasks,UserProfile
import base64
from datetime import datetime
import requests
# Create your views here.

INVITE_URL = "http://t.me/Tele_airdrop_token_bot/token?startapp="
REFERPOINTS = 58
PASSLIMIT = 1
REFERMESSAGE = lambda username: (
    f"**Success!** 🎉\n\n"
    f"You’ve successfully referred @{username} to our bot. Thank you for helping us grow! 🙌\n\n"
    f"We appreciate your support. Keep referring friends to earn more rewards and enjoy exclusive benefits! 🌟\n\n"
)
BOT_TOKEN = "7321713691:AAHS0T15WW1wqxH4ctg6si5CA88fetU5sFI"
HOST = "https://api.telegram.org"
URL_SEND = f"{HOST}/bot{BOT_TOKEN}/sendMessage"

def encode_string(input_string):
    """
    Encode a given string using Base64 encoding.

    :param input_string: The string to be encoded.
    :return: Base64 encoded string.
    """
    # Convert the string to bytes
    byte_data = input_string.encode('utf-8')
    
    # Perform Base64 encoding
    encoded_data = base64.b64encode(byte_data)
    
    # Convert the encoded bytes back to a string
    encoded_string = encoded_data.decode('utf-8')
    
    return encoded_string

def decode_string(encoded_string):
    """
    Decode a given Base64 encoded string.

    :param encoded_string: The Base64 encoded string to be decoded.
    :return: The original decoded string.
    """
    # Convert the encoded string to bytes
    encoded_data = encoded_string.encode('utf-8')
    
    # Perform Base64 decoding
    decoded_data = base64.b64decode(encoded_data)
    
    # Convert the decoded bytes back to a string
    decoded_string = decoded_data.decode('utf-8')
    
    return decoded_string

# To login on the website 
class CustomLoginForm(LoginView):
   template_name = 'Login.html'
   fields = ['username','password']
   redirect_authenticated_user = True
   
   
   def get_success_url(self):
       return reverse_lazy('index')

# To create  a task 
class taskCreate(LoginRequiredMixin,CreateView):
    model = tasks
    fields = ['Title','logic','reward','mode','url']
    
    success_url = reverse_lazy('index')
    
    def form_valid(self, form):
        mode = form.cleaned_data.get('mode')
        url = form.cleaned_data.get('url')
        if mode == "Url" and not url:
            form.add_error('url', 'URL is required when mode is set to "url".')
            return self.form_invalid(form)

        return super(taskCreate, self).form_valid(form)



def index(request):
    try:
        print(request)
        if request.method =="GET":
            user = request.GET.get("startapp",request.GET.get("tgWebAppStartParam"))
            
            try:
                data = request.GET.get("data","")
                parsed_query = urllib.parse.parse_qs(data)
                print(parsed_query)
                user_json = parsed_query.get('user', [None])[0]
                if user_json:
                    # Convert the JSON string to a Python dictionary
                    user_info = json.loads(user_json)

                    
                    # Retrieve the 'username' and 'user' values
                    username = user_info.get('username')
                    user_id = user_info.get('id')  # You can access other fields similarly
                    refer_id = decode_string(str(user))
                try:
                    userData = UserProfile.objects.get(user_id=str(user_id))
                except:
                    referUser = UserProfile.objects.get(user_id=str(refer_id))
                    referUser.token  = int(referUser.token) + int(REFERPOINTS)
                    referUser.friends += 1
                    referUser.playPass += PASSLIMIT
                    # Get the current date
                    current_date = datetime.now()
                    # Format the date as yy-mm-dd
                    formatted_date = current_date.strftime('%y-%m-%d')
                    referUser.Invited.append({"username":username,"time":formatted_date})
                    referUser.save()
                    msg = REFERMESSAGE(username)   
                    payload = {
                        'chat_id':refer_id,
                        "text":msg
                    }             
                    response = requests.post(URL_SEND, json=payload)

                return JsonResponse({"message":"Success"})
            except Exception as e:
                print(f"Erorr in refering : {e}")
                return render(request,'index.html')
        else:return render(request,'index.html')
    except:return render(request,'index.html')

# To get user data 
def getData(request,data):
    try:
        parsed_query = urllib.parse.parse_qs(data)
        user_json = parsed_query.get('user', [None])[0]
        if user_json:
            # Convert the JSON string to a Python dictionary
            user_info = json.loads(user_json)

            
            # Retrieve the 'username' and 'user' values
            username = user_info.get('username')
            user_id = user_info.get('id')  # You can access other fields similarly
            try:
                document = UserProfile.objects.get(user_id=str(user_id))
                user = True
                daily_reward = document.daily_reward
                rewards = document.rewards
                token = document.token
                friends = document.friends
                Invited = document.Invited
                Link = document.link
                gift = document.gift
                tapTap = document.tapTap
                playPass = document.playPass
                game = document.game
            except:
                user = False
                daily_reward = True
                rewards = []
                token = 0  
                friends = 0
                Invited = []
                Link = encode_string(str(user_id))
                Link  = INVITE_URL + Link
                gift = 0 
                tapTap = 0  
                playPass = 0 
                game = 0 
                add = UserProfile.objects.create(user_id=str(user_id),username=username,daily_reward=True,rewards=[],token=0,friends=0,Invited=[],link=Link,gift=gift,tapTap=tapTap,game=game)
            models = tasks.objects.all()
            tasks_list = []
            for i in models:
                title = i.Title
                logic = i.logic
                reward = i.reward
                completion = i.completed
                mode = i.mode
                url = i.url
                id = i.id

                if str(user_id) in  completion:
                    pass
                else:
                    completion[str(user_id)] = False
                tasks_list.append({"title":title,"logic":logic,"reward":reward,"completed":completion,"mode":mode,"url":url,"id":id})
                i.save()

             

            # Get top 100 users
            top_100_users = list(UserProfile.objects.order_by('-token').values('username', 'token')[:100])

            # Find the rank of the main user
            user_rank = UserProfile.objects.filter(token__gt=token).count() + 1
            users = UserProfile.objects.all()
            total_users = len(users)
            fetched_data = {"user":user,"user_id":user_id,"playPass":playPass,"daily_reward":daily_reward,"rewards":rewards,"token":token,"friends":friends,"invited":Invited,"tasks_list":tasks_list,"game":game,"gift":gift,"tapTap":tapTap,"rank":user_rank,"leaderboard":top_100_users,"total_users":total_users,"username":username,"invite_link":Link,"ReferPoints":REFERPOINTS,"botToken":BOT_TOKEN}
            print(f"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n{fetched_data}\n\n\n\n\n\n\n")
            return JsonResponse(fetched_data)
        else:
            return "Error"
    except Exception as e:
        print(e)
        return JsonResponse({"message":"error"})


def updateToken(request,user,token,query):
    
    user = UserProfile.objects.get(user_id=str(user))
    if query=="gift":
        user.gift = token
    elif query=="tap-tap":
        user.tapTap += token
    elif query=="game":
        user.game += token
    else:print("Elseeeeeeeee")
    user.token = user.token + token
    user.save()
    return JsonResponse({"message":"success","token":user.token})


def updatePass(request,user):
    print(request,user)
    user = UserProfile.objects.get(user_id=str(user))
    user.playPass = int(user.playPass) - 1
    user.save()
    return JsonResponse({"message":"success","playPass":user.playPass})

def updateTask(request,id,user):
    try:
        print(f"Request : {request} \n\n\n id : {id} \n\n\n user : {user}")
        task = tasks.objects.get(id=id)

        task.completed[str(user)] = True
        task.save()
        data = tasks.objects.get(id=id)
        print(data.completed)
    except Exception as e:
        print("Error : ",e)
    
    return JsonResponse({"message":"success","tasks":"done"})


def updateReward(request,user,num,day):
    user = UserProfile.objects.get(user_id=str(user))
    print(user.rewards)
    user.daily_reward = True
    print(len(user.rewards))
    if len((user.rewards))>0:
        print("Yes, it is greater than 1 or eqaul to ")
        previousDay = int(user.rewards[-1]["day"])
        currentDay = int(day)
        print(f"Previous day : {previousDay} \n Current day : {currentDay} ")
        if (currentDay- previousDay)<=1:
            user.rewards.append({"reward":int(num),"day":int(day)})
        else:
            user.rewards = [{"reward":int(num),"day":int(day)}]
    else:
        user.rewards = [{"reward":int(num),"day":int(day)}]
    print(user.rewards)
    user.save()
    return JsonResponse({"message":"success","rewards":user.rewards})



def game(request):
    return render(request,"game.html")