from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from django.conf import settings
from django.core.management import call_command

def start():
    # if settings.DEBUG:
    #     return  # Skip scheduling tasks in debug mode
    scheduler = BackgroundScheduler()
    scheduler.add_job(
        lambda: call_command('my_task'),
        trigger=CronTrigger(hour=0, minute=0, timezone='UTC'),  # Runs every day at 12:00 AM UTC
        id='daily_task',
        replace_existing=True,
    )
    scheduler.start()
