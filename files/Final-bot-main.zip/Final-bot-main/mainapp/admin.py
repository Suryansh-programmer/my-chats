from django.contrib import admin
from .models import tasks,UserProfile
# Register your models here.
admin.site.register(tasks)
admin.site.register(UserProfile)