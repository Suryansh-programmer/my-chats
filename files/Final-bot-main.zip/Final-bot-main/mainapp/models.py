from django.db import models
from django.contrib.postgres.fields import ArrayField
# Create your models here.
choices = (("Normal","Normal"),("Url","Url"),("Refer","Refer"))
class tasks(models.Model):
    Title = models.CharField(max_length=100)
    logic = models.CharField(max_length=1000)
    reward = models.IntegerField(default=0)
    completed = models.JSONField(default=dict,blank=True)
    mode = models.CharField(max_length=6,choices=choices,default="Normal")
    url = models.CharField(blank=True, null=True)  # New field to store the URL

class UserProfile(models.Model):
    user_id = models.CharField(max_length=10,null=True)
    
    username = models.CharField(max_length=100)
    daily_reward =  models.BooleanField(default=True) 
    rewards = ArrayField(
        models.JSONField(),  # Array of dictionaries with a max length of 20
        default=list,
    )
    token = models.IntegerField(default=0) 
    Invited = ArrayField(
        models.JSONField(),  # Array of dictionaries with a max length of 20
        default=list,
    )
    friends = models.IntegerField(default=0) 
    link = models.CharField(max_length=200,null=True)
    gift = models.IntegerField(null=True,default=0)
    tapTap = models.IntegerField(null=True,default=0)
    game = models.IntegerField(null=True,default=0)
    playPass = models.IntegerField(null=True,default=0)